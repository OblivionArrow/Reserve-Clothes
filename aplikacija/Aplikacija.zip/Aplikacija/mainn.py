from flask import Flask, Response, jsonify, request, render_template
import datetime as dt
import domainn as db
import simplejson as json
import os
         #Cross Origin Resource Sharing - komunikacija s frontendom

app = Flask(__name__)
# Dodajemo app u CORS kako bi bili u mogucnosti komunicirati s frontendom

# Error funkcija
def error(status=500, text='Doslo je do greske'):
    return jsonify({"error": text}), status

def popuni_bazu():
    id_ducan = "22222222"
    i = 11
    majica = "Majica "
    hlace = "Hlace "
    haljina = "Haljina "
    db.odmah(majica, i, id_ducan)
    i = i + 100
    db.odmah(hlace, i, id_ducan)
    i = i + 100
    db.odmah(haljina, i, id_ducan)
    i = i + 100
    id_ducan = "11111111"
    db.odmah(majica , i, id_ducan)
    i = i + 100
    db.odmah(hlace, i, id_ducan)
    i = i + 100
    db.odmah(haljina, i, id_ducan)


@app.route('/')
def hello():
    #popuni_bazu()
    return jsonify({
        'status' : 'success'
    })



########### Za klasu Korisnik ############

#   Dodavanje novog korisnika  #
@app.route('/registracija', methods=['GET', 'POST'])
def handle_korisnik_get_post():
	if request.method == 'POST':
		data = request.get_json()
		username = data.get('username')
		email = data.get('email')
		password = data.get('password')
		phone = data.get('phone')
		id_ = db.novi_korisnik(username, email, password, phone)
		
	return render_template("registracija.html")

#   Prijava postojeceg korisnika  #
@app.route('/korisnik/prijava', methods=['POST'])
def prijava_korisnika():
    post_data = request.get_json()
    # U frontendu se mora navesti 'email' i 'password' u poketu koji saljes za backend kako bi ga mogao iscitati ovdje
    email = post_data.get('email')
    password = post_data.get('password')
    # Pozivamo klasu Korisnik s funkcijom prijava i saljemo parametre. Vracene podatke spremamo u objekt 'korisnik'
    korisnik = db.prijava(email, password)
    if korisnik == None:
        return error()
    else:
        return jsonify({
            'status' : Resposne(status=201),
            # vraca sve korisnikove podatke
            'korisnik' : korisnik
        })

##################################################

########### Za klasu Ducan ############

#   Prijava postojeceg ducana   #
@app.route('/ducan/prijava', methods=['POST'])
def prijava_ducana():
    post_data = request.get_json()
    code = post_data.get('storeCode')
    password = post_data.get('storePassword')
    ducan = db.prijava_ducana(code, password)
    if ducan == None:
        return error()
    else:
        return jsonify({
            'status' : Resposne(status=201),
            'ducan' : ducan
        })

##################################################

########### Za klasu Rezervacija ############


#   Dodavanje nove rezervacije  #
@app.route('/nova-rezervacija', methods=['POST'])
def nova_rezervacija():
    post_data = request.get_json()
    korisnik_id = post_data.get('korisnikId')
    ducan_id = post_data.get('ducanId')
    artikal_id = post_data.get('artikalId')
    datum_t = post_data.get('datumTrenutni')
    datum_r = post_data.get('datumRezervacije')
    kolicina = post_data.get('kolicina')
    id_ = db.spremi_rezervaciju(korisnik, ducan, artikal, datum_t, datum_r, kolicina)
    if id_ == None:
        return error()
    else:
        return Resposne(status=201)

#   Izlistavanje svih rezervacija po korisniku   #
@app.route('/korisnik/rezervacije', methods=['POST'])
def izvjestaj_rezervacija_kor():
    post_data = request.get_json()
    korisnik_id = post_data.get('korisnikId')
    str = "id_korisnik"
    rezervacije = db.izlistaj_rez_za_tablicu(str, ducan_id)
    if rezervacije == None:
        return error()
    else:
        return jsonify({
            'status' : Resposne(status=201),
            'rezervacije' : rezervacije
        })

#   Izlistavanje svih rezervacija za trenutni ducan   #
@app.route('/ducan/rezervacije', methods=['POST'])
def izvjestaj_rezervacija_ducan():
    post_data = request.get_json()
    ducan_id = post_data.get('ducanId')
    str = "id_ducan"
    print(str)
    rezervacije = db.izlistaj_rez_za_tablicu(str, ducan_id)
    if rezervacije == None:
        return error()
    else:
        return jsonify({
            'status' : Resposne(status=201),
            'rezervacije' : rezervacije
        })
##################################################

########### Za klasu Artikli ############


#   Izlistavanje artikala u trenutnom ducanu   #
@app.route('/ducan/artikli', methods=['POST'])
def izvjestaj_artikala_ducan():
    post_data = request.get_json()
    ducan_id = post_data.get('ducanId')
    naziv = post_data.get('maziv')
    artikli = db.izlistaj_artikala(ducan_id, naziv)
    if artikli == None:
        return error()
    else:
        return jsonify({
            'status' : Resposne(status=201),
            'artikli' : artikli
        })


if __name__=="__main__": 
    app.secret_key=os.urandom(12)
    app.run(debug=True,host='0.0.0.0',port=5000)
	
